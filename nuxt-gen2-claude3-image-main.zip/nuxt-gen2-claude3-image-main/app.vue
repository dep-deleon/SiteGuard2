<template>
  <div>
    <NuxtPage />
  </div>
</template>
<style>
* {
  padding: 4px;
}
</style>

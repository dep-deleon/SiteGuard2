# Claude V3 Demo Using AWS Amplify Gen 2

This uses the new [Claude 3 Vision](https://docs.anthropic.com/claude/reference/messages-examples) API with [AWS Amplify Gen 2](https://docs.amplify.aws/gen2/)

This is made for the [Program With Erik](http://erik.video) YouTube channel!
